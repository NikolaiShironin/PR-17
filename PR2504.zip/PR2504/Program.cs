﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PR2504
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Добавление в список");
            List<string> people = new List<string>() { "Tom" };
            people.Add("Bob");
            people.AddRange(new[] { "Sam", "Alice" });
            people.Insert(0, "Eugene");
            people.InsertRange(1, new string[] { "Mike", "Kate" });
            foreach (string p in people)
            {
                Console.WriteLine(p);
            }
            Console.ReadKey();
            Console.WriteLine("Удаление из списка");
            var people1 = new List<string>() { "Eugene", "Mike", "Kate", "Tom", "Bob", "Sam", "Tom", "Alice" };
            people.RemoveAt(1);
            people.Remove("Tom");
            people.RemoveAll(person => person.Length == 3);
            people.RemoveRange(1, 2);
            people.Clear();
            foreach (string p in people1)
            {
                Console.WriteLine(p);
            }
            Console.ReadKey();
        }
    }
}
